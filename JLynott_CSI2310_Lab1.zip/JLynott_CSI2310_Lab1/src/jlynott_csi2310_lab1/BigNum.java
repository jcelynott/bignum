/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jlynott_csi2310_lab1;

/**
 *
 * @author James
 */
public class BigNum {
    
    String stringNum; //This is the number imput by the user as the base string version of our BigNum
    
    public BigNum(String num)
    {
        stringNum = num;
    }
    
    
    public String Add(BigNum secondNum)
    {
        String longerNum, smallerNum, sumNum; //longerNum is a number >= to smallerNum, the two numbers being added. sumNum is the resultant sum
        int carry = 0, sum = 0; //Carry is a value that is used if a 1 has to be carried over a place. Sum is the sum of two corresponding digits of each string
        
        if(secondNum.toString().length() > stringNum.length())
        {
            longerNum = secondNum.toString();
            smallerNum = stringNum;
        }
        
        else
        {
            longerNum = stringNum;
            smallerNum = secondNum.toString();
        }
        
        while(longerNum.length() - smallerNum.length() > 0)
        {
            smallerNum = "0" + smallerNum;
        }
        
        longerNum = "0" + longerNum;
        smallerNum = "0" + smallerNum;
        
        sumNum = "";
        
        for(int i = longerNum.length() - 1; i >= 0; i--)
        {
            sum = Character.getNumericValue(longerNum.charAt(i)) +Character.getNumericValue(smallerNum.charAt(i)) + carry;
            if(sum >= 10)
            {
                carry = 1;
                sum = sum - 10;
            }
            
            else
                carry = 0;
            
            sumNum = sum + sumNum;
            
        }
        
        
        while(sumNum.startsWith("0"))
        {
            sumNum = sumNum.substring(1);
        }
        
        if(sumNum.equals(""))
                sumNum = "0";
        
        return sumNum;
        
    }
    
    public String toString()
    {
        String s = stringNum;
        
        while(s.startsWith("0"))
        {
            s = s.substring(1);
        }
        
        return s;
        
    } 
}
