/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jlynott_csi2310_lab1;

import static java.time.Clock.system;
import java.util.Scanner;

/**
 *
 * @author James
 */
public class JLynott_CSI2310_Lab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String stringNumOne, stringNumTwo;
        Scanner scanner = new Scanner(System.in);
         
        System.out.println("Please input the value of the first number");     
        stringNumOne = scanner.nextLine();
        
        System.out.println("Please input the value of the second number");    
        stringNumTwo = scanner.nextLine();
        
        BigNum numOne = new BigNum(stringNumOne);
        BigNum numTwo = new BigNum(stringNumTwo);
        
        System.out.println(numOne.toString() + " + " + numTwo.toString() + " = " + numOne.Add(numTwo));
        
    }
    
}
